USE [ER_PROJECT]

-- ترتیب پاک کردن اهمیت دارد
DELETE FROM GhalameFactor;
DELETE FROM Factor;
DELETE FROM Anbar;
DELETE FROM Kala;
DELETE FROM Karbar;



INSERT INTO Anbar(ID_anbar, nam) VALUES (1, 'انبار مرکزی');
INSERT INTO Anbar(ID_anbar, nam) VALUES (2, 'انبار فروش 1');
INSERT INTO Anbar(ID_anbar, nam) VALUES (3, 'انبار فروش 2');

INSERT INTO Kala(ID_kala, nam, vahed_sanjesh) VALUES (1, 'شکر', 'کیلو');
INSERT INTO Kala(ID_kala, nam, vahed_sanjesh, tozihat) VALUES (2, 'نوشابه', 'عدد', 'نوشابه مشکی');
INSERT INTO Kala(ID_kala, nam, vahed_sanjesh, tozihat) VALUES (3, 'دوغ', 'باکس', 'دوغ سنتی');
INSERT INTO Kala(ID_kala, nam, vahed_sanjesh, tozihat) VALUES (4, 'شکلات', 'گرم', 'شکلات تلخ');
INSERT INTO Kala(ID_kala, nam, vahed_sanjesh, tozihat) VALUES (5, 'شیر', 'لیتر', 'شیر پر چرب');

INSERT INTO Karbar(ID_karbar, nam, nam_khanevadegi, code_meli, shomare_telephone) VALUES (1, 'مهدیه','رحیمی', null, '+985743472833');
INSERT INTO Karbar(ID_karbar, nam, nam_khanevadegi, code_meli, shomare_telephone) VALUES (2, 'مبینا', 'مومنی', '1234567890', null);
INSERT INTO Karbar(ID_karbar, nam, nam_khanevadegi, code_meli, shomare_telephone) VALUES (3, 'فاطمه', 'امجدی', '9752135795', '+983458377485');
INSERT INTO Karbar(ID_karbar, nam, nam_khanevadegi, code_meli, shomare_telephone) VALUES (4, 'نسترن', 'فلک الدین', '0192837465', '+989438477564');
INSERT INTO Karbar(ID_karbar, nam, nam_khanevadegi, code_meli, shomare_telephone) VALUES (5, 'زهرا', 'حیدری', '6574839201', '+981424321423');

INSERT INTO Factor(ID_factor, ID_karbar, ID_anbar, shomare, noe_factor, mablaghe_kol, takhfif_kol, maliat_avarez_kol) VALUES (1, 2, 2, 1, 1, 19200, 4300, 300);
INSERT INTO Factor(ID_factor, ID_karbar, ID_anbar, shomare, noe_factor, mablaghe_kol, takhfif_kol, maliat_avarez_kol) VALUES (2, 4, 3, 2, 2, 31500, 600, 130);

INSERT INTO GhalameFactor(ID_ghalame_factor, ID_factor, ID_kala, fee, meghdar, takhfif, maliat_avarez) VALUES (1, 1, 4, 110, 120, 3300, 100);
INSERT INTO GhalameFactor(ID_ghalame_factor, ID_factor, ID_kala, fee, meghdar, takhfif, maliat_avarez) VALUES (2, 1, 5, 1200, 5, 1000, 200);

INSERT INTO GhalameFactor(ID_ghalame_factor, ID_factor, ID_kala, fee, meghdar, takhfif, maliat_avarez) VALUES (3, 2, 1, 9000, 3.5, 600, 130);



-- لیست فاکتور ها
SELECT
    F.shomare,
    K.nam AS 'name_karbar',
    K.nam_khanevadegi AS 'name_khanevadegi_karbar',
    A.nam AS 'name_anbar',
    CASE
        WHEN F.noe_factor = 1 THEN 'forosh'
        WHEN F.noe_factor = 2 THEN 'kharid'
        ELSE '-'
    END AS 'noe_factor',
    F.mablaghe_kol,
    F.takhfif_kol,
    F.maliat_avarez_kol,
    F.mablaghe_khales

FROM Factor F
LEFT JOIN Anbar A ON F.ID_anbar = A.ID_anbar
LEFT JOIN Karbar K ON F.ID_karbar = K.ID_karbar

-- لیست اقلام فاکتور ها
SELECT
    F.shomare AS 'shomare_factor', K.nam AS 'name_kala', G.fee, G.meghdar, G.takhfif, G.maliat_avarez, G.mablaghe_khales
FROM GhalameFactor G
INNER JOIN Factor F ON G.ID_factor = F.ID_factor
INNER JOIN Kala K ON G.ID_kala = K.ID_kala
-- برای این که اقلام یک فاکتور خاص به ترتیب نمایش داده شوند مرتب میکنیم
ORDER BY F.shomare

-- لیست کالا ها
SELECT * FROM Kala;

-- لیست انبار ها
SELECT * FROM Anbar;

-- لیست کاربر ها
SELECT * FROM Karbar;

USE [master]