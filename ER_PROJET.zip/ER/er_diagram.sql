﻿CREATE DATABASE [ER_PROJECT]; 
GO 

ALTER DATABASE [ER_PROJECT]
COLLATE Persian_100_CS_AS_KS_WS_SC_UTF8
GO

USE [ER_PROJECT];
GO


---------------------- Anbar ---------------------

CREATE TABLE [dbo].[Anbar]
(
    [ID_anbar] INT NOT NULL PRIMARY KEY,
    [nam] NVARCHAR(150) NOT NULL
);
GO

---------------------- Kala ----------------------

CREATE TABLE [dbo].[Kala]
(
    [ID_kala] INT NOT NULL PRIMARY KEY,
    [nam] NVARCHAR(150) NOT NULL,
    [vahed_sanjesh] NVARCHAR(150) NOT NULL,
    [tozihat] NVARCHAR(500) NULL
);
GO

---------------------- Karbar --------------------

CREATE TABLE [dbo].[Karbar]
(
    [ID_karbar] INT NOT NULL PRIMARY KEY,
    [nam] NVARCHAR(150) NOT NULL,
    [nam_khanevadegi] NVARCHAR(150) NOT NULL,
    [code_meli] CHAR(10) NULL,
    [shomare_telephone] CHAR(13) NULL
);
GO

---------------------- Factor --------------------

CREATE TABLE [dbo].[Factor]
(
    [ID_factor] INT NOT NULL PRIMARY KEY,
    [ID_karbar] INT NOT NULL FOREIGN KEY REFERENCES Karbar(ID_karbar), --ب ستون کاربر تو جدول اشاره میکنه
    [ID_anbar] INT NOT NULL FOREIGN KEY REFERENCES Anbar(ID_anbar),
    [shomare] INT INDEX ix_factor_shomare, --ایندکس برای پیدا کردن توی مثلا هزارتا جدوله
    [noe_factor] INT NOT NULL,  -- 1: forosh, 2:kharid
    [mablaghe_kol] DECIMAL(18,4),
    [takhfif_kol] DECIMAL(18,4), --دسیمال برای نگهداری داده های عددیه  ک مقدار رو از دست نمیدی(گرد میکنه خوردشم نگه میداره
    [maliat_avarez_kol] DECIMAL(18,4),
    [mablaghe_khales] AS [mablaghe_kol] + [maliat_avarez_kol] - [takhfif_kol]
	--برحسب دیتا های دیگ حساب میکنن اینا رو مثل صفتای مشتقن ینی همونان
);
GO

-- ALTER TABLE Factor
-- ADD FOREIGN KEY (ID_karbar) REFERENCES Karbar(ID_karbar);
-- GO

-- CREATE INDEX ix_factor_shomare
-- ON Factor(shomare);
-- GO

---------------------- GhalameFactor -------------

CREATE TABLE [dbo].[GhalameFactor]
(
    [ID_ghalame_factor] INT NOT NULL PRIMARY KEY,
    [ID_factor] INT NOT NULL FOREIGN KEY REFERENCES Factor(ID_factor),
    [ID_kala] INT NOT NULL, --FOREIGN KEY REFERENCES Kala(ID_kala),
    [fee] DECIMAL(18,4),
    [meghdar] DECIMAL(18,4),
    [takhfif] DECIMAL(18,4),
    [maliat_avarez] DECIMAL(18,4),
    [mablaghe_khales] AS ([meghdar] * [fee]) + [maliat_avarez] - [takhfif]
);
GO

ALTER TABLE GhalameFactor
ADD FOREIGN KEY (ID_kala) REFERENCES Kala(ID_kala);
GO

-- USE [master]
-- DROP DATABASE [ER_PROJECT]