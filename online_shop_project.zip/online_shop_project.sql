-- create the database
CREATE DATABASE [ONLINE_SHOP];
GO

USE [ONLINE_SHOP]
ALTER DATABASE [ONLINE_SHOP]
COLLATE Persian_100_CS_AS_KS_WS_SC_UTF8

-- creatie tables
CREATE TABLE Category (
  ID INT NOT NULL PRIMARY KEY,
  [name] NVARCHAR(250) NULL
);

CREATE TABLE Customer (
  ID INT NOT NULL PRIMARY KEY,
  first_name NVARCHAR(250) NOT NULL,
  last_name NVARCHAR(250) NOT NULL,
  contact_num NVARCHAR(15) NOT NULL,
  address_contact NVARCHAR(500) NULL
)

CREATE TABLE Payment (
  ID INT NOT NULL PRIMARY KEY,
  [status] INT NOT NULL DEFAULT 0
)

CREATE TABLE Seller (
  ID INT NOT NULL PRIMARY KEY,
  customer_ID INT NULL FOREIGN KEY REFERENCES Customer(ID)
)

CREATE TABLE Product (
  ID INT NOT NULL PRIMARY KEY,
  amount DECIMAL(18, 4) NULL,
  category_ID INT NULL FOREIGN KEY REFERENCES Category(ID),
  seller_ID INT NULL FOREIGN KEY REFERENCES Seller(ID),
)

CREATE TABLE Shopping_order (
  ID INT NOT NULL PRIMARY KEY,
  customer_ID INT NULL FOREIGN KEY REFERENCES Customer(ID),
  payment_ID INT NULL FOREIGN KEY REFERENCES Payment(ID),
  delivered BIT NOT NULL DEFAULT(0),
  date_order date NULL
)

CREATE TABLE Shopping_order_item (
  ID INT NOT NULL PRIMARY KEY,
  Shopping_order_ID INT NULL FOREIGN KEY REFERENCES Shopping_order(ID),
  product_ID INT NULL FOREIGN KEY REFERENCES Product(ID),
  amount DECIMAL(18, 4) NOT NULL,
)

GO
-- insert into tables

INSERT INTO Category ([ID], [name]) VALUES
(1, 'پوشاک'),
(2, 'لوازم الکترونیکی'),
(3, 'لوازم خانه'),
(4, 'اکسسوری مردانه'),
(5, 'اکسسوری زنانه'),
(6, 'لپ تاپ'),
(7, 'موبایل'),
(8, 'دوربین عکاسی');

INSERT INTO Customer ([ID], [first_name], [last_name], [contact_num], [address_contact]) VALUES
(1, 'مهدی', 'توکلی ', '09031693291', 'اصفهان'),
(2, 'رسول', 'حسینی', '09031693292', 'اصفهان'),
(3, 'حسین', 'لاله طاهری', '09031693293', 'تهران'),
(4, 'علی', 'پور محمدی', '09031693294', 'رشت');

INSERT INTO Payment ([ID], [status]) VALUES
(1, 20000),
(2, 50000),
(3, 80000),
(4, 6000000),
(5, 800000000),
(6, 68524500);

INSERT INTO Seller ([ID], [customer_ID]) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4);

INSERT INTO Product ([ID], [amount], [category_ID], [seller_ID]) VALUES
(1, 20000, 2, 4),
(2, 4000, 3, 3),
(3, 5000, 4, 2),
(4, 200, 5, 1);

INSERT INTO Shopping_order ([ID], [customer_ID], [payment_ID], [delivered], [date_order]) VALUES
(1, 1, 2, 0, '2022-05-26');

INSERT INTO Shopping_order_item ([ID], [Shopping_order_ID], [product_ID], [amount]) VALUES
(1, 1, 1, 10);

GO
-- select commands
SELECT * FROM Shopping_order;
SELECT * FROM Product;
SELECT * FROM Seller;
SELECT * FROM Payment;
SELECT * FROM Customer;
SELECT * FROM Category;

-- not delivered orders count for a customer
SELECT 
    CU.ID,
    CU.first_name,
    CU.last_name,
    CU.contact_num,
    CU.address_contact,
    COUNT(SO.ID) AS 'Not delivered orders count'
FROM Shopping_order SO
INNER JOIN Customer CU ON SO.customer_ID = CU.ID
WHERE SO.delivered = 0
GROUP BY CU.ID, CU.first_name, CU.last_name, CU.contact_num, CU.address_contact

-- three most selled categories
SELECT TOP 3
    CA.ID, CA.name
FROM Category CA
RIGHT JOIN Product P on CA.ID = P.category_ID
LEFT JOIN Shopping_order_item OI on P.ID = OI.product_ID
GROUP BY CA.ID, CA.name
ORDER BY SUM(OI.amount) DESC

GO
-- delete tables
DROP TABLE Shopping_order_item;
DROP TABLE Shopping_order;
DROP TABLE Product;
DROP TABLE Seller;
DROP TABLE Payment;
DROP TABLE Customer;
DROP TABLE Category;

GO
-- delete database
USE [master]
DROP DATABASE [ONLINE_SHOP]